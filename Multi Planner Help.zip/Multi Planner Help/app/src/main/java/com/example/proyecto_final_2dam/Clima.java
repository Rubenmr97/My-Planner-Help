package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Clima extends AppCompatActivity {

    ImageButton btn_tiempo1,btn_tiempo2,btn_tiempo3,btn_tiempo4;
    Button volvertiempo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clima);

        btn_tiempo1=findViewById(R.id.imageButtonTiempo1);
        btn_tiempo2=findViewById(R.id.imageButtonTiempo2);
        btn_tiempo3=findViewById(R.id.imageButtonTiempo3);
        btn_tiempo4=findViewById(R.id.imageButtonTiempo4);
        volvertiempo=findViewById(R.id.buttonVolverTiempo);

    }

    public void tiempo1(View view) {

        if (view.getId() == R.id.imageButtonTiempo1) {
            Uri webpage = Uri.parse("https://www.eltiempo.es/");
            Intent intentTiempo1 = new Intent(Intent.ACTION_VIEW, webpage);
            if (intentTiempo1.resolveActivity(getPackageManager()) != null) {
                startActivity(intentTiempo1);

            }
        }
    }

    public void tiempo2(View view) {

        if (view.getId() == R.id.imageButtonTiempo2) {
            Uri webpage = Uri.parse("https://www.tiempo.com/");
            Intent intentTiempo2 = new Intent(Intent.ACTION_VIEW, webpage);
            if (intentTiempo2.resolveActivity(getPackageManager()) != null) {
                startActivity(intentTiempo2);

            }
        }
    }

    public void tiempo3(View view) {

        if (view.getId() == R.id.imageButtonTiempo3) {
            Uri webpage = Uri.parse("http://www.eltiempo.tv/");
            Intent intentTiempo3 = new Intent(Intent.ACTION_VIEW, webpage);
            if (intentTiempo3.resolveActivity(getPackageManager()) != null) {
                startActivity(intentTiempo3);

            }
        }
    }

    public void tiempo4(View view) {

        if (view.getId() == R.id.imageButtonTiempo4) {
            Uri webpage = Uri.parse("https://www.tutiempo.net/");
            Intent intentTiempo4 = new Intent(Intent.ACTION_VIEW, webpage);
            if (intentTiempo4.resolveActivity(getPackageManager()) != null) {
                startActivity(intentTiempo4);

            }
        }
    }

    public void Botonvolvertiempoainicio(View view){

        Intent intenttiempo= new Intent(this,pantalla_inicial.class);
        startActivity(intenttiempo);
    }
}
