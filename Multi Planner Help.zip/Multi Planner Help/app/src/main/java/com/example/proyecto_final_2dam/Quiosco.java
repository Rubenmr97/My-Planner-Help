package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class Quiosco extends AppCompatActivity {

    ImageButton ib_noticias, ib_not_depor,ib_juegos,ib_cocina,ib_moda,ib_tec,ib_econ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiosco);
        ib_noticias=findViewById(R.id.imageButtonimboton_noticias);
        ib_not_depor=findViewById(R.id.imageButtonimboton_noticias_deportivas);
        ib_moda=findViewById(R.id.imageButtonimgbtn_Moda);
        ib_cocina=findViewById(R.id.imageButtonimgbtn_cocina);
        ib_econ=findViewById(R.id.imageButtonimgbtn_Economia);
        ib_juegos=findViewById(R.id.imageButtonimgbtn_juegos);
        ib_tec=findViewById(R.id.imageButtonimgbtn_tecno);
    }

    public void noticias(View view){

        Intent intentBus_A_incio = new Intent(this,Informacion.class);
        startActivity(intentBus_A_incio);

    }

    public void noticiasDepor(View view){

        Intent intentBus_A_incio = new Intent(this,Info_deportiva.class);
        startActivity(intentBus_A_incio);

    }

    public void economia(View view){

        Intent intentBus_A_incio = new Intent(this,Economia.class);
        startActivity(intentBus_A_incio);

    }

    public void tecno(View view){

        Intent intentBus_A_incio = new Intent(this,Tecno.class);
        startActivity(intentBus_A_incio);
    }

    public void juego(View view){

        Intent intentBus_A_incio = new Intent(this,Juegos.class);
        startActivity(intentBus_A_incio);
    }

    public void Cocina(View view){

        Intent intentBus_A_incio = new Intent(this,Cocina.class);
        startActivity(intentBus_A_incio);
    }

    public void Moda(View view){
        Intent intentBus_A_incio = new Intent(this,Moda.class);
        startActivity(intentBus_A_incio);
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_quiosco,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id= item.getItemId();
        if(id==R.id.ButtonMQuiosco1){
            Toast.makeText(this,"Inicio",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,pantalla_inicial.class);
            startActivity(intentBus_A_incio);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
