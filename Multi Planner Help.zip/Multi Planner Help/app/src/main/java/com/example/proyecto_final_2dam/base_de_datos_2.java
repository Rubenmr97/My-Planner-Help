package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class base_de_datos_2 extends AppCompatActivity {

    EditText evento, ubicacion, fecha;
    TextView er;
    Button insert,delet, conslt;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base_de_datos_2);
        evento= (EditText) findViewById(R.id.editTextNombre);
        ubicacion=(EditText)findViewById(R.id.editTextUbicacion);
        fecha=(EditText)findViewById(R.id.editTextFecha);
        insert=(Button) findViewById(R.id.buttonInsertar);
        delet=(Button)findViewById(R.id.buttonBorrar);
        conslt=(Button)findViewById(R.id.buttonConsultar);
        er=(TextView)findViewById(R.id.Resultado_bd);
    }


    public void insertar(View view){

        BaseDeDatosAgenda admin = new
                BaseDeDatosAgenda(this,"agenda", null,1);

        SQLiteDatabase BasedeDatos = admin.getReadableDatabase();

        String num_orden= evento.getText().toString();
        String valor_ubicaion= ubicacion.getText().toString();
        String valor_fecha = fecha.getText().toString();

        ContentValues contenido = new
                ContentValues();
        contenido.put("evento",num_orden);
        contenido.put("ubicacion", valor_ubicaion);
        contenido.put("fecha",valor_fecha);

        BasedeDatos.insert("agenda",null,contenido);
        BasedeDatos.close();

        Toast.makeText(this,"Se ha insertado "+num_orden+" , "+valor_ubicaion+" , "+valor_fecha, Toast.LENGTH_LONG).show();


    }

    public void consultar(View view){

        BaseDeDatosAgenda admin = new
                BaseDeDatosAgenda(this, "agenda",null,1);

        SQLiteDatabase BasedeDatos = admin.getReadableDatabase();
        System.out.println("Antes de leerr");

        String num_orden=evento.getText().toString();
        System.out.println(" prueba");
        if(!num_orden.isEmpty()){

            Cursor fila = BasedeDatos.rawQuery("select ubicacion, fecha from agenda " +
                    "where evento="+num_orden,null);

            if(fila.moveToFirst()){
               er.setText(" Ubicacion: "+ fila.getString(1) + "  Fecha: "+fila.getString(2));
                BasedeDatos.close();


            }else {

                Toast.makeText(this,"No hay ubicacion para ese evento",Toast.LENGTH_LONG).show();
                BasedeDatos.close();
            }

        }else {
            Toast.makeText(this,"Debes introducir un evento",Toast.LENGTH_LONG).show();
        }
    }

    public void eliminar(View view){

        BaseDeDatosAgenda admin = new
                BaseDeDatosAgenda(this, "agenda",null,1);

        SQLiteDatabase BasedeDatos = admin.getReadableDatabase();

        String num_orden=evento.getText().toString();

        if(!num_orden.isEmpty()){

            BasedeDatos.delete("agenda","evento="+num_orden,null);
            Toast.makeText(this,"Se ha eliminado el evento ",Toast.LENGTH_LONG).show();
            BasedeDatos.close();

        }else{
            Toast.makeText(this, "Teclea un evento valido", Toast.LENGTH_LONG).show();

        }
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_base_datos,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id= item.getItemId();
        if(id==R.id.ButtonMBaseDatos1){
            Toast.makeText(this,"Inicio",Toast.LENGTH_LONG).show();
            Intent intentBD_A_incio = new Intent(this,pantalla_inicial.class);
            startActivity(intentBD_A_incio);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
