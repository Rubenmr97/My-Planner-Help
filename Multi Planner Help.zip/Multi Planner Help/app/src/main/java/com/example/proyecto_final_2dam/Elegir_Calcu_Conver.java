package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Elegir_Calcu_Conver extends AppCompatActivity {

    Button calcu, conver, volver;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elegir__calcu__conver);
        calcu=findViewById(R.id.buttonCalculadora);
        conver=findViewById(R.id.buttonConversor);
        volver=findViewById(R.id.buttonVolver);

    }

    public void Calculadora(View view){

        Intent intentCalc = new Intent(this,Calculadora.class);
        startActivity(intentCalc);
    }

    public void Conversor(View view){

        Intent intentCalc = new Intent(this,Conversor.class);
        startActivity(intentCalc);
    }

    public void Volver(View view){
        Intent intentVolver = new Intent(this,pantalla_inicial.class);
        startActivity(intentVolver);
    }
}
