package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class MapaMetro extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    String mi_url;
    String mi_ciu;
    Button confirmar;
    Spinner lista;

    String[] Ciudades={"Madrid","Barcelona","Bilbao", "Valencia","Sevilla"};
    String[] url={"https://www.planometromadrid.org/","https://www.metrobarcelona.es/mapas.html","http://planosdemetro.com/bilbao/","https://www.metrovalencia.es/descargas/pdf/PlanoRed_Metrovalencia_Julio2016.pdf","http://planosdemetro.com/plano-del-metro-de-sevilla/"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapa_metro);

        confirmar=findViewById(R.id.buttonConfirmM);
        lista=findViewById(R.id.spinnerListaM);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Ciudades);
        lista.setAdapter(adapter);
        lista.setOnItemSelectedListener(this);
    }

    public void MapaMetro(View view){


        Intent intentMetro = new Intent(this,Mapa_metro_dos.class);
        intentMetro.putExtra("miurl",mi_url);
        intentMetro.putExtra("miciudad",mi_ciu);
        startActivity(intentMetro);
    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        Toast.makeText(this, "Has elegido: " + Ciudades[position], Toast.LENGTH_LONG).show();
        mi_url=(url[position]);
        mi_ciu=(Ciudades[position]);

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_metro,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id= item.getItemId();
        if(id==R.id.ButtonMMetro1){
            Toast.makeText(this,"Inicio",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,pantalla_inicial.class);
            startActivity(intentBus_A_incio);
            return true;
        }

        if(id==R.id.ButtonMMetro2){
            Toast.makeText(this,"Volviendo ..",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,Mapas_2.class);
            startActivity(intentBus_A_incio);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

