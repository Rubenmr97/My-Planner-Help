package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class Mapas_2 extends AppCompatActivity {

    ImageButton ibtn_GM, ibtn_metro, ibtn_GMS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapas_2);

        ibtn_GM=findViewById(R.id.imageButtonMapsN);
        ibtn_metro=findViewById(R.id.imageButtonmetro);
        ibtn_GMS=findViewById(R.id.imageButtonGMS);
    }



    public void GoogleMS (View view){

        if(view.getId()==R.id.imageButtonGMS){
            Uri we= Uri.parse("https://www.google.es/maps/@39.862125,-4.1395162,36336m/data=!3m1!1e3");
            Intent intent = new Intent(Intent.ACTION_VIEW,we);
            if(intent.resolveActivity(getPackageManager())!=null) {
                startActivity(intent);

            }
        }
    }


    public void MapaNormal (View view){

        if(view.getId()==R.id.imageButtonMapsN){
            Uri we= Uri.parse("https://www.google.com/maps/place/Madrid/@40.4378698,-3.8196207,11z/data=!3m1!4b1!4m5!3m4!1s0xd422997800a3c81:0xc436dec1618c2269!8m2!3d40.4167754!4d-3.7037902");
            Intent intent = new Intent(Intent.ACTION_VIEW,we);
            if(intent.resolveActivity(getPackageManager())!=null) {
                startActivity(intent);

            }
        }
    }

    public void Bus (View view){

        Intent intentbus = new Intent( this, MapaBus.class);
        startActivity(intentbus);
    }

    public void Metro (View view){

        Intent intentmetro = new Intent( this, MapaMetro.class);
        startActivity(intentmetro);
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_mapa_1,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id= item.getItemId();
        if(id==R.id.ButtonMMapa1) {
            Toast.makeText(this, "Inicio", Toast.LENGTH_LONG).show();
            Intent intentretro = new Intent(this, pantalla_inicial.class);
            startActivity(intentretro);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
