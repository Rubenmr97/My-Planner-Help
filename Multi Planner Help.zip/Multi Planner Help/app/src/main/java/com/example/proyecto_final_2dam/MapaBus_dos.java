package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MapaBus_dos extends AppCompatActivity {

    TextView texto;
    Button volver, buscar;
    String url_seg, ciud_seg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapa_bus_dos);

        texto=findViewById(R.id.textViewNombreCiudadM);
        volver=findViewById(R.id.buttonVolver);
        buscar=findViewById(R.id.buttonBuscaMapa);

        Bundle extras = getIntent().getExtras();
        url_seg=extras.getString("miurl");
        ciud_seg=extras.getString("miciudad");

        texto.setText(ciud_seg);
    }

    public void volver(View view){

        Intent intentvolver = new Intent(this, MapaBus.class);
        startActivity(intentvolver);
    }


    public void ir (View view){

        if(view.getId()==R.id.buttonBuscaMapa){
            Uri web = Uri.parse(url_seg);
            Intent intent = new Intent(Intent.ACTION_VIEW,web);
            if(intent.resolveActivity(getPackageManager())!=null) {
                startActivity(intent);
            }
        }
    }

}
