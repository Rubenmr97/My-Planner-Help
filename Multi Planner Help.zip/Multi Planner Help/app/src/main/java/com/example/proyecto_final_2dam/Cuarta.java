package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class Cuarta extends AppCompatActivity implements AdapterView.OnItemSelectedListener {


    String mi_url;
    String mi_ciu;
    Button confirmar;
    Spinner lista;

    String[] Ciudades={"Toledo","Madrid","Barcelona","Bilbao", "Valencia"};
    String[] url={"https://calendarios.ideal.es/laboral/castilla-la-mancha/toledo/toledo","https://www.elperiodico.com/es/economia/20191002/calendario-laboral-madrid-2020-fiestas-festivos-7662387","https://www.elperiodico.com/es/economia/20191002/calendario-laboral-festivos-barcelona-2020-7661097","https://www.calendarioslaborales.com/calendario-laboral-bilbao-2020.htm","https://www.calendarioslaborales.com/calendario-laboral-valencia-2020.htm"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuarta);


        confirmar=findViewById(R.id.buttonConfirm_Calen_Lab);
        lista=findViewById(R.id.spinnerLista_lab);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Ciudades);
        lista.setAdapter(adapter);
        lista.setOnItemSelectedListener(this);

    }



    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_calendario_2,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id= item.getItemId();
        if(id==R.id.ButtonMCalendar2_1){
            Toast.makeText(this,"Inicio",Toast.LENGTH_LONG).show();
            Intent intentCalend_A_incio = new Intent(this,pantalla_inicial.class);
            startActivity(intentCalend_A_incio);
            return true;
        }
        if(id==R.id.ButtonMCalendar2_2){
            Toast.makeText(this,"Volviendo ..",Toast.LENGTH_LONG).show();
            Intent intentCalend_a_calend = new Intent(this,CalendarioActivity.class);
            startActivity(intentCalend_a_calend);
            return true;
        }
        if(id==R.id.ButtonMCalendar2_3){
            Toast.makeText(this,"Escolar",Toast.LENGTH_LONG).show();
            Intent intentCalend_a_siguiente = new Intent(this,tercerapantalla.class);
            startActivity(intentCalend_a_siguiente);
            return true;
        }

        if(id==R.id.ButtonMCalendar2_4){
            Toast.makeText(this,"Deportivo",Toast.LENGTH_LONG).show();
            Intent intentCalend_a_siguiente = new Intent(this,Quinta.class);
            startActivity(intentCalend_a_siguiente);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        Toast.makeText(this, "Has elegido: " + Ciudades[position], Toast.LENGTH_LONG).show();
        mi_url=(url[position]);
        mi_ciu=(Ciudades[position]);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void CalenLab(View view){

        Intent intentLab = new Intent(this,Confirmar_calendarios.class);
        intentLab.putExtra("miurl",mi_url);
        intentLab.putExtra("miciudad",mi_ciu);
        startActivity(intentLab);
    }
}
