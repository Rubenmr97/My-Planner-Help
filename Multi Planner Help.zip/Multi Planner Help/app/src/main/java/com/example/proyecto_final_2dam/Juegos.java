package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class Juegos extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Spinner listanoticias;
    String url_juego, pag_juego;
    Button bt_busca;

    String[] Juegos={"3D Juegos","Meristation","Epic Games","Steam","Istant Gaming"};
    String[] url_juegos={"https://www.3djuegos.com/","https://as.com/meristation/","https://www.epicgames.com/store/es-ES/","https://store.steampowered.com/?l=spanish","https://www.instant-gaming.com/es/"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juegos);

        bt_busca=findViewById(R.id.buttonBusca_juegos);
        listanoticias=findViewById(R.id.spinnerLista_juegos);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Juegos);
        listanoticias.setAdapter(adapter);
        listanoticias.setOnItemSelectedListener(this);


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        Toast.makeText(this, "Has elegido: " + Juegos[position], Toast.LENGTH_LONG).show();
        url_juego=(url_juegos[position]);
        pag_juego=(Juegos[position]);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    public void ir (View view){

        if(view.getId()==R.id.buttonBusca_juegos){
            Uri web = Uri.parse(url_juego);
            Intent intent = new Intent(Intent.ACTION_VIEW,web);
            if(intent.resolveActivity(getPackageManager())!=null) {
                startActivity(intent);
            }
        }
    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_juegos,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id= item.getItemId();
        if(id==R.id.ButtonMJuegos1){
            Toast.makeText(this,"Inicio",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,pantalla_inicial.class);
            startActivity(intentBus_A_incio);
            return true;
        }

        if(id==R.id.ButtonMJuegos2){
            Toast.makeText(this,"Volviendo ..",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,Quiosco.class);
            startActivity(intentBus_A_incio);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
