package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class MapaBus extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    String mi_url;
    String mi_ciu;
    Button confirmar;
    Spinner lista;

    String[] Ciudades={"Toledo","Madrid","Barcelona","Bilbao", "Valencia"};
    String[] url={"http://www.toledo.es/servicios-municipales/policia-local-y-movilidad/transportes/","https://navegapormadrid.emtmadrid.es/app/","https://www.tmb.cat/es/transporte-barcelona/mapa/bus","https://www.bilbao.eus/cs/Satellite/bilbobus/es/lineas-bilbobus/mapa-de-lineas","http://www.valencia-cityguide.com/es/guia-de-turismo/mapas/mapa-de-autobuses-de-valencia.html"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapa_bus);

        confirmar=findViewById(R.id.buttonConfirm);
        lista=findViewById(R.id.spinnerLista);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Ciudades);
        lista.setAdapter(adapter);
        lista.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        Toast.makeText(this, "Has elegido: " + Ciudades[position], Toast.LENGTH_LONG).show();
        mi_url=(url[position]);
        mi_ciu=(Ciudades[position]);
        //Toast.makeText(this,"Direccion URL"+ url[position], Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void Mapabus(View view){

        Intent intentBus = new Intent(this,MapaBus_dos.class);
        intentBus.putExtra("miurl",mi_url);
        intentBus.putExtra("miciudad",mi_ciu);
        startActivity(intentBus);
    }



    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_bus,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id= item.getItemId();
        if(id==R.id.ButtonMBus_1){
            Toast.makeText(this,"Inicio",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,pantalla_inicial.class);
            startActivity(intentBus_A_incio);
            return true;
        }

        if(id==R.id.ButtonMBus_2){
            Toast.makeText(this,"Volviendo ..",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,Mapas_2.class);
            startActivity(intentBus_A_incio);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
