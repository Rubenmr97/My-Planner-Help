package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Conversor extends AppCompatActivity{

    EditText cantidad;
    TextView resultado;
    Button dol, yen, lib;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversor);

        cantidad=findViewById(R.id.editTextCantidad);
        resultado=findViewById(R.id.textViewResultado);
        dol=findViewById(R.id.buttonDolares);
        yen=findViewById(R.id.buttonYenes);
        lib=findViewById(R.id.buttonLibras);
    }

    public void dolar (View view){

        double dolares = 1.10;
        double res ;
        String cant1;
        cant1= cantidad.getText().toString();
        double cant2 = Double.parseDouble(cant1);
        res= cant2 * dolares;
        String total = Double.toString(res);
        resultado.setText(total);
    }

    public void Yen(View view){

        double yenes = 118.04;
        double res ;
        String cant1;
        cant1= cantidad.getText().toString();
        double cant2 = Double.parseDouble(cant1);
        res= cant2 * yenes;
        String total = Double.toString(res);
        resultado.setText(total);
    }

    public void Libras (View view){

        double libras = 0.90;
        double res ;
        String cant1;
        cant1= cantidad.getText().toString();
        double cant2 = Double.parseDouble(cant1);
        res= cant2 * libras;
        String total = Double.toString(res);
        resultado.setText(total);
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menuconversor,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id= item.getItemId();
        if(id==R.id.ButtonMConver1){
            Toast.makeText(this,"Inicio",Toast.LENGTH_LONG).show();
            Intent intentConversor_A_incio = new Intent(this,pantalla_inicial.class);
            startActivity(intentConversor_A_incio);
            return true;
        }
        if(id==R.id.ButtonMConver2){
            Toast.makeText(this,"Volviendo ..",Toast.LENGTH_LONG).show();
            Intent intentConversor_A_elegir = new Intent(this,Elegir_Calcu_Conver.class);
            startActivity(intentConversor_A_elegir);
            return true;
        }
        if(id==R.id.ButtonMConver3){
            Toast.makeText(this,"Calculadora",Toast.LENGTH_LONG).show();
            Intent intentConversor_a_calcu = new Intent(this,Calculadora.class);
            startActivity(intentConversor_a_calcu);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
