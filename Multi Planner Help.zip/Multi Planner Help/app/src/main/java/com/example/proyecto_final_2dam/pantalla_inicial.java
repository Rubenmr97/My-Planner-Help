package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class pantalla_inicial extends AppCompatActivity {

    ImageButton ibtCalendario, ibtBaseDatos, ibtMapas, ibtTiempo, ibtCalculadora;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_inicial);
        ibtCalendario=findViewById(R.id.imageButtonCalendario);
        ibtBaseDatos=findViewById(R.id.imageButtonBaseDatos);
        ibtMapas=findViewById(R.id.imageButtonMapas);
        ibtTiempo=findViewById(R.id.imageButtonTiempo);
        ibtCalculadora=findViewById(R.id.imageButtonCalculadora);
    }

    public void Calendario(View view){

        Intent intentCalc = new Intent(this,CalendarioActivity.class);
        startActivity(intentCalc);
    }

    public void Elegir(View view){

        Intent intentCalc = new Intent(this,Elegir_Calcu_Conver.class);
        startActivity(intentCalc);
    }

    public void tiempo(View view){

        Intent intentClima = new Intent(this,Clima.class);
        startActivity(intentClima);
    }

    public void mapa (View view){

        Intent intentmapa = new Intent(this,Mapas_2.class);
        startActivity(intentmapa);
    }

    public  void BaseDatos (View view){

        Intent intentBD= new Intent(this,base_de_datos_2.class);
        startActivity(intentBD);
    }

    public  void Quiosco (View view){

        Intent intentQ= new Intent(this,Quiosco.class);
        startActivity(intentQ);
    }
}
