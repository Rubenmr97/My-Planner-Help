package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class CalendarioActivity extends AppCompatActivity {

    Button btn_otros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendario);
        btn_otros=findViewById(R.id.buttonOtros);

    }

    public void BotonOtros(View view){

        Intent intentotros = new Intent(this,tercerapantalla.class);
        startActivity(intentotros);
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.calendario,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id= item.getItemId();
        if(id==R.id.ButtonMCalendar1){
            Toast.makeText(this,"Inicio",Toast.LENGTH_LONG).show();
            Intent intentCalend_A_incio = new Intent(this,pantalla_inicial.class);
            startActivity(intentCalend_A_incio);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
