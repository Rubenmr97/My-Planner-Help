package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class Informacion extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    String url_not, pag_not;
    Button buscar;
    Spinner listanoticias;

    String[] Noticias={"El Pais","El Mundo","Libertad Digital","20minutos", "Nius"};
    String[] noticia_url={"https://elpais.com/noticias/paginas-web/","https://www.elmundo.es/espana.html","https://www.libertaddigital.com/internet/libertad-digital-mejor-sitio-de-noticias-de-espana-1276269846/",
            "https://www.20minutos.es/","https://www.niusdiario.es/nacional/"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informacion);

        buscar=findViewById(R.id.buttonBuscaNoticias);
        listanoticias=findViewById(R.id.spinnerListaNoticias);



        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Noticias);
        listanoticias.setAdapter(adapter);
        listanoticias.setOnItemSelectedListener(this);

    }



    public void ir (View view){

        if(view.getId()==R.id.buttonBuscaNoticias){
            Uri web = Uri.parse( url_not);
            Intent intent = new Intent(Intent.ACTION_VIEW,web);
            if(intent.resolveActivity(getPackageManager())!=null) {
                startActivity(intent);
            }
        }
    }



    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        Toast.makeText(this, "Has elegido: " + Noticias[position], Toast.LENGTH_LONG).show();
        url_not=(noticia_url[position]);
        pag_not=(Noticias[position]);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_noticias,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id= item.getItemId();
        if(id==R.id.ButtonMNoticias1){
            Toast.makeText(this,"Inicio",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,pantalla_inicial.class);
            startActivity(intentBus_A_incio);
            return true;
        }

        if(id==R.id.ButtonMNoticias2){
            Toast.makeText(this,"Volviendo ..",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,Quiosco.class);
            startActivity(intentBus_A_incio);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }




}
