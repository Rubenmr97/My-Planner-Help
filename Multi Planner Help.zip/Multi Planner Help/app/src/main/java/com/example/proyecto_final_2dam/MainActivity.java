package com.example.proyecto_final_2dam;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    ImageButton fb, gm, insta, twt;
    Button botonprueba;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionbar = getSupportActionBar();
        actionbar.hide();

        fb=findViewById(R.id.imageButton_FB);
        gm=findViewById(R.id.imageButton_GM);
        insta=findViewById(R.id.imageButton_INSTA);
        twt=findViewById(R.id.imageButton_TWT);
        botonprueba=findViewById(R.id.buttonRegistroprueba);
    }


    public void Facebook (View view){

        if(view.getId()==R.id.imageButton_FB){
            Uri webpage= Uri.parse("https://es-es.facebook.com/");
            Intent intent = new Intent(Intent.ACTION_VIEW,webpage);
            if(intent.resolveActivity(getPackageManager())!=null) {
                startActivity(intent);

            }
        }
    }

    public void Gmail(View view){

        if(view.getId()==R.id.imageButton_GM){
            Uri webpage= Uri.parse("https://accounts.google.com/signin/v2/identifier?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F%3Ftab%3Drm%26ogbl&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin");
            Intent intent = new Intent(Intent.ACTION_VIEW,webpage);
            if(intent.resolveActivity(getPackageManager())!=null) {
                startActivity(intent);

            }
        }
    }

    public void Instagram (View view){

        if(view.getId()==R.id.imageButton_INSTA){
            Uri webpage= Uri.parse("https://www.instagram.com/?hl=es-la");
            Intent intent = new Intent(Intent.ACTION_VIEW,webpage);
            if(intent.resolveActivity(getPackageManager())!=null) {
                startActivity(intent);

            }
        }
    }

    public void Twitter(View view){

        if(view.getId()==R.id.imageButton_TWT){
            Uri webpage= Uri.parse("https://twitter.com/explore");
            Intent intent = new Intent(Intent.ACTION_VIEW,webpage);
            if(intent.resolveActivity(getPackageManager())!=null) {
                startActivity(intent);

            }
        }
    }

    public void Botonprueba(View view){

        Intent intentCalc = new Intent(this,pantalla_inicial.class);
        startActivity(intentCalc);
    }


}
