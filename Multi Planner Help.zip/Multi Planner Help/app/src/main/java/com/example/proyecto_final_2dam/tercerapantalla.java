package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class tercerapantalla extends AppCompatActivity implements AdapterView.OnItemSelectedListener {


    String url_esco, ciu_esco;
    Button confirmar_esco;
    Spinner listaEsco;

    String[] Ciudades={"Toledo","Madrid","Barcelona","Bilbao", "Valencia"};
    String[] url_calen={"http://www.educa.jccm.es/es/calendario-escolar","https://www.educa2.madrid.org/web/calendario-escolar-de-la-comunidad-de-madrid","https://www.elperiodico.com/es/sociedad/20190620/calendario-escolar-catalunya-2019-2020-7514273",
            "https://calendarios.ideal.es/escolar/pais-vasco/bizkaia/bilbao?ref=https%3A%2F%2Fwww.google.com%2F","https://www.levante-emv.com/especiales/calendario-laboral/calendario-escolar-2019-2020"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tercerapantalla);


        confirmar_esco=findViewById(R.id.buttonConfirma_calen_Esco);
        listaEsco=findViewById(R.id.spinnerLista_esco);


        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Ciudades);
        listaEsco.setAdapter(adapter);
        listaEsco.setOnItemSelectedListener(this);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        Toast.makeText(this, "Has elegido: " + Ciudades[position], Toast.LENGTH_LONG).show();
        url_esco=(url_calen[position]);
        ciu_esco=(Ciudades[position]);

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void CalenEsco(View view){

        Intent intentEsco = new Intent(this,Confirmar_calendarios.class);
        intentEsco.putExtra("miurl_esco",url_esco);
        intentEsco.putExtra("miciudad_esco",ciu_esco);
        startActivity(intentEsco);
    }


    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_calendario_1,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id= item.getItemId();
        if(id==R.id.ButtonMCalendar1_1){
            Toast.makeText(this,"Inicio",Toast.LENGTH_LONG).show();
            Intent intentcalenESco_A_incio = new Intent(this,pantalla_inicial.class);
            startActivity(intentcalenESco_A_incio);
            return true;
        }

        if(id==R.id.ButtonMCalendar1_2){
            Toast.makeText(this,"Volviendo ..",Toast.LENGTH_LONG).show();
            Intent intentcalenESco_A_calendario = new Intent(this,CalendarioActivity.class);
            startActivity(intentcalenESco_A_calendario);
            return true;
        }

        if(id==R.id.ButtonMCalendar1_3){
            Toast.makeText(this,"Siguiente",Toast.LENGTH_LONG).show();
            Intent intentcalenESco_A_cuarta = new Intent(this,Cuarta.class);
            startActivity(intentcalenESco_A_cuarta);
            return true;
        }

        if(id==R.id.ButtonMCalendar1_4){
            Toast.makeText(this,"Siguiente",Toast.LENGTH_LONG).show();
            Intent intentcalenESco_A_cuarta = new Intent(this,Quinta.class);
            startActivity(intentcalenESco_A_cuarta);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }




}
