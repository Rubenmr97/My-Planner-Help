package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class Quinta extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    String  url_depor, ciu_depor;
    Button confirmar_depor;
    Spinner  listaDepor;

    String[] Deportes={"Fútbol","Tenis","Baloncesto","Moto GP"};
    String[] url_deportiva={"https://resultados.as.com/resultados/futbol/primera/calendario/","https://www.eurosport.es/tenis/atp/calendar-result.shtml",
            "https://resultados.as.com/resultados/baloncesto/acb/calendario/","https://www.marca.com/motor/motogp/calendario.html"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quinta);

        confirmar_depor=findViewById(R.id.buttonConfirma_calen_depor);
        listaDepor=findViewById(R.id.spinnerLista_depor);

        ArrayAdapter<String> adapterDos = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Deportes);
        listaDepor.setAdapter(adapterDos);
        listaDepor.setOnItemSelectedListener(this);
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        Toast.makeText(this, "Has elegido: " + Deportes[position], Toast.LENGTH_LONG).show();
        url_depor=(url_deportiva[position]);
        ciu_depor=(Deportes[position]);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void CalenDepor(View view){

        Intent intentDepor = new Intent(this,Confirmar_calendarios.class);
        intentDepor.putExtra("miurl_depor", url_depor);
        intentDepor.putExtra("deporte",ciu_depor);
        startActivity(intentDepor);
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_calendario_3,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id= item.getItemId();
        if(id==R.id.ButtonMCalendar4_1){
            Toast.makeText(this,"Inicio",Toast.LENGTH_LONG).show();
            Intent intentCalend_A_incio = new Intent(this,pantalla_inicial.class);
            startActivity(intentCalend_A_incio);
            return true;
        }
        if(id==R.id.ButtonMCalendar4_2){
            Toast.makeText(this,"Volviendo ..",Toast.LENGTH_LONG).show();
            Intent intentCalend_a_calend = new Intent(this,CalendarioActivity.class);
            startActivity(intentCalend_a_calend);
            return true;
        }
        if(id==R.id.ButtonMCalendar4_3){
            Toast.makeText(this,"Escolar",Toast.LENGTH_LONG).show();
            Intent intentCalend_a_siguiente = new Intent(this,tercerapantalla.class);
            startActivity(intentCalend_a_siguiente);
            return true;
        }

        if(id==R.id.ButtonMCalendar4_4){
            Toast.makeText(this,"Laboral",Toast.LENGTH_LONG).show();
            Intent intentCalend_a_siguiente = new Intent(this,Cuarta.class);
            startActivity(intentCalend_a_siguiente);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
