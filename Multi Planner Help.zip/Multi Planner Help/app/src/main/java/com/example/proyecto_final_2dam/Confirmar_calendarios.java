package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Confirmar_calendarios extends AppCompatActivity {

    Button btn_esco, btn_depor, btn_lab;
    TextView tv_esco, tv_depor,tv_lab;

    String url_esco, url_depor, url_lab;
    String ciu_esco, ciu_depor, ciu_lab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmar_calendarios);

        btn_esco=findViewById(R.id.buttonBusca_Calen_esc);
        btn_depor=findViewById(R.id.buttonBusca_Calen_depor);
        btn_lab=findViewById(R.id.buttonBusca_Calen_lab);
        tv_esco=findViewById(R.id.textViewRes_calen_esc);
        tv_depor=findViewById(R.id.textViewRes_calen_depor);
        tv_lab=findViewById(R.id.textViewRes_calen_lab);

        // recoge la eleccion del calendario laboral

        Bundle extras = getIntent().getExtras();
        url_lab=extras.getString("miurl");
        ciu_lab=extras.getString("miciudad");
        tv_lab.setText(ciu_lab);

        // recoge la eleccion del calendario escolar

        Bundle extras_es = getIntent().getExtras();
        url_esco=extras_es.getString("miurl_esco");
        ciu_esco=extras_es.getString("miciudad_esco");
        tv_esco.setText(ciu_esco);

        // recoge la eleccion del calendario deportivo

        Bundle extras_de = getIntent().getExtras();
        url_depor=extras_de.getString("miurl_depor");
        ciu_depor=extras_de.getString("deporte");
        tv_depor.setText(ciu_depor);

    }

    public void ir_lab (View view){

        if(view.getId()==R.id.buttonBusca_Calen_lab){
            Uri web_lab = Uri.parse(url_lab);
            Intent intent = new Intent(Intent.ACTION_VIEW,web_lab);
            if(intent.resolveActivity(getPackageManager())!=null) {
                startActivity(intent);
            }
        }
    }

    public void ir_esco (View view){

        if(view.getId()==R.id.buttonBusca_Calen_esc){
            Uri web_es = Uri.parse(url_esco);
            Intent intent = new Intent(Intent.ACTION_VIEW,web_es);
            if(intent.resolveActivity(getPackageManager())!=null) {
                startActivity(intent);
            }
        }
    }

    public void ir_depor (View view){

        if(view.getId()==R.id.buttonBusca_Calen_depor){
            Uri web_de = Uri.parse(url_depor);
            Intent intent = new Intent(Intent.ACTION_VIEW,web_de);
            if(intent.resolveActivity(getPackageManager())!=null) {
                startActivity(intent);
            }
        }
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_confirmar_calendarios,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id= item.getItemId();
        if(id==R.id.ButtonMCalendar3_1){
            Toast.makeText(this,"Inicio",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,pantalla_inicial.class);
            startActivity(intentBus_A_incio);
            return true;
        }

        if(id==R.id.ButtonMCalendar3_2){
            Toast.makeText(this,"Laboral ..",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,Cuarta.class);
            startActivity(intentBus_A_incio);
            return true;
        }

        if(id==R.id.ButtonMCalendar3_3){
            Toast.makeText(this,"Escolar",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,tercerapantalla.class);
            startActivity(intentBus_A_incio);
            return true;
        }
        if(id==R.id.ButtonMCalendar3_4){
            Toast.makeText(this,"deportivo",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,Quinta.class);
            startActivity(intentBus_A_incio);
            return true;
        }

        if(id==R.id.ButtonMCalendar3_5){
            Toast.makeText(this,"Calendario ..",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,CalendarioActivity.class);
            startActivity(intentBus_A_incio);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }}
