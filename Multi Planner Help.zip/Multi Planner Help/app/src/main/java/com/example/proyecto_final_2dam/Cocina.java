package com.example.proyecto_final_2dam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class Cocina extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Spinner listanoticias;
    String url_eco, pag_eco;
    Button bt_busca;

    String[] Cocina={"Webos Fritos","Cerezos En Flor","Hogarmania","Cocinatis","Cocinando Entre Olivos"};
    String[] url_Cocina={"https://webosfritos.es/","http://www.loscerezosenflor.com/","https://www.hogarmania.com/","https://www.cocinatis.com/","https://cocinandoentreolivos.com/"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cocina);


        bt_busca=findViewById(R.id.buttonBusca_cocina);
        listanoticias=findViewById(R.id.spinnerLista_Cocina);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Cocina);
        listanoticias.setAdapter(adapter);
        listanoticias.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(this, "Has elegido: " + Cocina[position], Toast.LENGTH_LONG).show();
        url_eco=(url_Cocina[position]);
        pag_eco=( Cocina[position]);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void ir (View view){

        if(view.getId()==R.id.buttonBusca_cocina){
            Uri web = Uri.parse(url_eco);
            Intent intent = new Intent(Intent.ACTION_VIEW,web);
            if(intent.resolveActivity(getPackageManager())!=null) {
                startActivity(intent);
            }
        }
    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_cocina,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id= item.getItemId();
        if(id==R.id.ButtonMCocina1){
            Toast.makeText(this,"Inicio",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,pantalla_inicial.class);
            startActivity(intentBus_A_incio);
            return true;
        }

        if(id==R.id.ButtonMCocina2){
            Toast.makeText(this,"Volviendo ..",Toast.LENGTH_LONG).show();
            Intent intentBus_A_incio = new Intent(this,Quiosco.class);
            startActivity(intentBus_A_incio);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
